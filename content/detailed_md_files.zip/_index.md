---
title: "Reciklažica | Рециклажица"
metaDescription: "Reciklažica - ежемесячная акция по сбору вторсырья у населения Черногории"
metaKeywords: "переработка, отходы, рециклирование, вторсырье, мусор, акция, черногория, бар, сутоморе, будва, радановичи, котор, рисан, херцег нови, тиват, подгорица, цетине, сортировка, пластик, батарейки, алюминий, бумага, картон, железо, жесть, фольга, крышечки"
pageSpinner: "Загрузка..."
firstNavLang: "CG"
secondNavLang: "EN"
lightThemeMode: "Светлый"
darkThemeMode: "Тёмный"
textH1: "Reciklažica - Рециклажица"
textLocations: "Черногория,<br>Бар - Сутоморе - Будва - Тиват - Котор - Херцег Нови - Кумбор"
linkTg: "Наш Телеграм"
linkFb: "Facebook группа"



272,276c270,274
<             <h2 class="h1 text-center text-sm-start mb-4">Что такое Рециклажица?</h2>
<             <p>Вы долго этого ждали! Впервые в Черногории экоакция Reciklažica (Рециклажица)!💚</p>
<             <p><em>Каждую последнюю субботу месяца</em> в определённых городах Черногории движение «Зелёная Адриатика» собирает вторсырьё от жителей страны. </p>
<             <p class="pb-2 pb-lg-4 pb-xl-5 mb-3">После акции вторсырьё поедет на Двориште общины Котор, где будет сдано заготовителям для дальнейшей передачи переработчикам.</p>
<             <h3 class="text-center text-sm-start mb-4">Наши Достижения</h3>
---
>             <h2 class="h1 text-center text-sm-start mb-4">Šta je Reciklažica?</h2>
>             <p>Ovo ste dugo čekali! Prva ekološka akcija u Crnoj Gori - Reciklažica!💚</p>
>             <p><em>Svake poslednje subote u mesecu</em> u određenim gradovima Crne Gore, pokret "Zeleni Jadran" sakuplja sekundarne sirovine od građana države. </p>
>             <p class="pb-2 pb-lg-4 pb-xl-5 mb-3">Posle akcije, sekundarne sirovine će se naći na Dvorištu opštine Kotor, gde će biti predate dobavljačima, za dalju predaju prerađivačima.</p>
>             <h3 class="text-center text-sm-start mb-4">Naša dostignuća</h3>
285c283
<                   <h4 class="fs-base fw-semibold text-nowrap ps-1 mb-0">Последний раз</h4>
---
>                   <h4 class="fs-base fw-semibold text-nowrap ps-1 mb-0">Poslednji put</h4>
288c286
<                 <h5 class="text-primary my-2 my-sm-0">1300 кг</h5>
---
>                 <h5 class="text-primary my-2 my-sm-0">1300 kg</h5>
290c288
<                 <div class="fs-sm">31 Августа 2024</div>
---
>                 <div class="fs-sm">31. avgust 2024</div>
297c295
<                   <h4 class="fs-base fw-semibold text-nowrap ps-1 mb-0">Всего</h4>
---
>                   <h4 class="fs-base fw-semibold text-nowrap ps-1 mb-0">Ukupno</h4>
300,301c298,299
<                 <h5 class="badge bg-primary fs-5 fw-bold rounded px-3 py-0 my-3 my-sm-0">26.100 кг</h5>
<                 <div class="fs-sm">За всё время<div>
---
>                 <h5 class="badge bg-primary fs-5 fw-bold rounded px-3 py-0 my-3 my-sm-0">26.100 kg</h5>
>                 <div class="fs-sm">Za sve vrijeme</div>
310c308
321c319
<                 <p class="ps-3 mb-0">Городов-участников акции. География постоянно расширяется</p>
---
>                 <p class="ps-3 mb-0">gradova učestvuje u akciji, koja se neprestano širi</p>
328c326
<                 <p class="ps-3 mb-0">успешно проведенных акций</p>
---
>                 <p class="ps-3 mb-0">uspješnih akcija je provedeno</p>
335c333
<                 <p class="ps-3 mb-0">Неравнодушных к проблеме. Телеграм группа неуклонно растёт</p>
---
>                 <p class="ps-3 mb-0">ljudi zainteresovanih za problem. Grupa na Telegramu neprekidno raste</p>
348c346
<           <h2 class="h1 text-center text-md-start mb-lg-4 pt-1 pt-md-4">Что принимается?!</h2>
---
>           <h2 class="h1 text-center text-md-start mb-lg-4 pt-1 pt-md-4">Šta recikliramo?!</h2>
351,352c349,350
<               <p class="fs-lg text-muted mb-md-0">Черногория делает свои первые шаги во вторичной переработке и не всё, что нам бы хотелось, сейчас может быть переработано.</p>
<               <p class="fs-lg text-muted mb-md-0">Обратите внимание, что <mark>только 4 типа вторсырья</mark> сейчас принимаются волонтёрами на Рециклажице:</p>
---
>               <p class="fs-lg text-muted mb-md-0">Crna Gora pravi svoje prve korake u sekundarnoj preradi, i trenutno može biti prerađeno i ono što ne bismo hteli da bude.</p>
>               <p class="fs-lg text-muted mb-md-0">Obratite pažnju, volonteri Reciklažice trenutno primaju <mark>samo 4 tipa sekundarne sirovine:</p>
365c363
<                     <img src="assets/img/icons/logo-plastic.png" class="d-block mb-3" width="100" alt="Logo">
---
>                     <img src="../assets/img/icons/logo-plastic.png" class="d-block mb-3" width="100" alt="Logo">
368c366
<                     Пластик
---
>                     Plastika
371c369
<                   <p class="py-2 pb-lg-3 mb-3 border-top">Принимаются следующие категории пластика:</p>
---
>                   <p class="py-2 pb-lg-3 mb-3 border-top">Primaju se sledeće kategorije plastike:</p>
373,380c371,378
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>01 PET(E): </strong>Прозрачные бутылки из-под напитков (голубые, зелёные, коричневые)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>01 PET(E): </strong>Цветные бутылки из-под напитков (йогурт, кефир)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>02 HDPE: </strong>Упаковка из-под бытовой химии с крышками (порошок, кондиционер, средство для мытья посуды, чистящие средства)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>02 HDPE: </strong>Пакеты</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>02 HDPE: </strong>Крышечки</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>04 LDPE: </strong>Пакеты, зип-локи</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>05 PP: </strong>Упаковка из-под молочных продуктов (йогурты, сметана, каймак, брынза)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>05 PP: </strong>Крупногабаритный пластик (столы, стулья, ящики)</li>
---
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>01 PET(E): </strong>Providne flaše od napitaka (plave, zelene, braon)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>01 PET(E): </strong>Obojene flaše od napitaka (jogurt, kefir)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>02 HDPE: </strong>Pakovanja kućne hemije sa poklopcima (prašak, omekšivač, sredstvo za pranje posuđa, sredstva za čišćenje)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>02 HDPE: </strong>Kese</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>02 HDPE: </strong>Čepovi</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>04 LDPE: </strong>Kese, kesice sa zatvaračem (ziplock)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>05 PP: </strong>Pakovanje mlečnih proizvoda (jogurt, pavlaka, kajmak, sir)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>05 PP: </strong>Krupna plastika (stolovi, stolice, kutije)</li>
383c381
<                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>НЕ ПРИНИМАЕТСЯ:</strong></u></p>
---
>                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>NE PRIHVATAMO:</strong></u></p>
385,393c383,391
<                         <li>Пенопласт</li>
<                         <li>Вспененные белые поддончики для еды (сыр, ветчина)</li>
<                         <li>Пластиковые тюбики из-под зубной пасты</li>
<                         <li>Прозрачные упаковочные контейнеры из-под еды</li>
<                         <li>Упаковка из-под чипсов</li>
<                         <li>ПВХ, трубы для канализации и сантехники</li>
<                         <li>Нейлон (зубные щётки, носки, колготки)</li>
<                         <li>Пакеты с наклейками</li>
<                         <li>ГРЯЗНОЕ, НЕМЫТОЕ</li>
---
>                         <li>Stiropor</li>
>                         <li>Penaste bele kutijice za hranu (sir, šunka)</li>
>                         <li>Plastične tube od paste za zube</li>
>                         <li>Providna pakovanja za hranu</li>
>                         <li>Pakovanje čipsa</li>
>                         <li>PVC, cevi za kanalizaciju i sanitarije</li>
>                         <li>Najlon (četke za zube, čarape, najlonke)</li>
>                         <li>Kese sa naljepnicama</li>
>                         <li>PRLJAVO, NEOPRANO</li>
405c403
<                     <img src="assets/img/icons/logo-metal.png" class="d-block mb-3" width="100" alt="Logo">
---
>                     <img src="../assets/img/icons/logo-metal.png" class="d-block mb-3" width="100" alt="Logo">
408c406
<                     Железо, жесть, алюминий
---
>                     Gvožđe, kalaj, aluminijum
411c409
<                   <p class="py-2 pb-lg-3 mb-3 border-top">Принимаются следующие виды вторсырья:</p>
---
>                   <p class="py-2 pb-lg-3 mb-3 border-top">Prihvatamo sledeće tipove sekundarnih sirovina:</p>
413,415c411,413
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>40 FE: </strong>Жестяные банки из под еды</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>41 ALU: </strong>Алюминиевые банки</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>41 ALU: </strong>Фольга (сама фольга, верхние фольгированные крышечки/наклейки от сметаны, йогурта)</li>
---
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>40 FE: </strong>Konzerve za hranu od kalaja</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>41 ALU: </strong>Aluminijumske konzerve</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>41 ALU: </strong>Folija (folija sama po sebi, poklopci od folije/nalepnice od pavlake, jogurta)</li>
418c416
<                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>НЕ ПРИНИМАЕТСЯ:</strong></u></p>
---
>                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>NE PRIHVATAMO:</strong></u></p>
420,422c418,420
<                         <li>Упаковка из-под чипсов</li>
<                         <li>РЖАВОЕ</li>
<                         <li>ГРЯЗНОЕ, НЕМЫТОЕ</li>
---
>                         <li>Pakovanje od čipsa</li>
>                         <li>RĐAVO</li>
>                         <li>PRLJAVO, NEOPRANO</li>
434c432
<                     <img src="assets/img/icons/logo-paper.png" class="d-block mb-3" width="100" alt="Logo">
---
>                     <img src="../assets/img/icons/logo-paper.png" class="d-block mb-3" width="100" alt="Logo">
437c435
<                     Бумага, картон
---
>                     Papir, karton
440c438
<                   <p class="py-2 pb-lg-3 mb-3 border-top">Принимаются следующие бумажные продукты:</p>
---
>                   <p class="py-2 pb-lg-3 mb-3 border-top">Prihvatamo sledeće papirne predmete:</p>
442,444c440,442
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>20 PAP: </strong>Крупный картон (коробки)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>21 PAP: </strong>Картонная упаковка (яйца, хлопья, мюсли, каши)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>22 PAP: </strong>Бумага (газеты, книги, журналы, тетради)</li>
---
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>20 PAP: </strong>Krupan karton (kutije)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>21 PAP: </strong>Kartonska pakovanja (jaja, žitarice, musli, kaše)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>22 PAP: </strong>Papir (novine, knjige, časopisi, sveske)</li>
447c445
<                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>НЕ ПРИНИМАЕТСЯ:</strong></u></p>
---
>                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>NE PRIHVATAMO:</strong></u></p>
449,455c447,453
<                         <li>Термобумага (чеки)</li>
<                         <li>Тетрапак</li>
<                         <li>Бумага, содержащая пластик</li>
<                         <li>Бумага со скотчем</li>
<                         <li>Салфетки</li>
<                         <li>МОКРОЕ, ГРЯЗНОЕ</li>
<                         <li>СО СЛЕДАМИ ЖИРА</li>
---
>                         <li>Termalni papir (računi)</li>
>                         <li>Tetrapak</li>
>                         <li>Papir koji sadrži plastiku</li>
>                         <li>Papir sa selotejpom</li>
>                         <li>Maramici</li>
>                         <li>MOKRO, PRLJAVO</li>
>                         <li>SA MASNIM TRAGOVIMA</li>
467c465
<                     <img src="assets/img/icons/logo-battery.png" class="d-block mb-3" width="100" alt="Logo">
---
>                     <img src="../assets/img/icons/logo-battery.png" class="d-block mb-3" width="100" alt="Logo">
470c468
<                     Батарейки
---
>                     Baterije
473c471
<                   <p class="py-2 pb-lg-3 mb-3 border-top">Принимаются следующие категории:</p>
---
>                   <p class="py-2 pb-lg-3 mb-3 border-top">Prihvataju se sledeće kategorije:</p>
475,481c473,479
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>08 Lead: </strong>Автомобильные аккумуляторы</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>09 Alkaline: </strong>Алкалиновые батарейки (пульты, фонарики, AA, AAA)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>10 NiCd: </strong>Старые Никель-кадмиевые аккумуляторы</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>11 NiMH: </strong>Никель-металлогидридный аккумуляторы</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>12 Li: </strong>Литиевые аккумуляторы (телефоны, камеры, фотоаппараты, компьютеры)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>13 SO(Z): </strong>Серебряно-цинковые батарейки (часы, брелки)</li>
<                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>14 CZ: </strong>Марганцево-цинковые элементы (крупные батарейки в фонарики)</li>
---
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>08 Lead: </strong>Akumulatori za automobile</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>09 Alkaline: </strong>Alkalne baterije (daljinski upravljači, lampe, AA, AAA)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>10 NiCd: </strong>Stare Nikl-kadmijum baterije</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>11 NiMH: </strong>Stare Nikl-metalohidridne baterije</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>12 Li: </strong>Litijumske baterije (telefoni, kamere, fotoaparati, kompjuteri)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>13 SO(Z): </strong>Baterijice od srebra i cinka (satovi, ključevi)</li>
>                       <li><i class="bx bx-recycle fs-4 text-primary me-1 icon-position-low"></i><strong>14 CZ: </strong>Elementi od mangana i cinka (velike baterije u baterijskim lampama)</li>
484c482
<                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>НЕ ПРИНИМАЕТСЯ:</strong></u></p>
---
>                       <p class="pb-2 pb-lg-3 mb-3"><u><strong>NE PRIHVATAMO:</strong></u></p>
486,487c484,485
<                         <li>ГРЯЗНОЕ, НЕМЫТОЕ</li>
<                         <li>РЖАВОЕ</li>
---
>                         <li>PRLJAVO, NEOPRANO</li>
>                         <li>RĐAVO</li>
501c499
<         <div class="row mt-xl-2 mb-xl-3 pb-3 py-md-4 py-lg-5">
---
>         <div class="row pt-1">
503c501
<             <h2 class="h1 text-center text-sm-start pb-2 pb-lg-0 mb-4 mb-lg-5">Расписание</h2>
---
>             <h2 class="h1 text-center text-sm-start pb-2 pb-lg-0 mb-4 mb-lg-5">Raspored</h2>
510c508
<                 <div class="fs-xl">Суббота</div>
---
>                 <div class="fs-xl">Subota</div>
512c510
<                 <div class="fs-3 fw-bold">28 Сентября 2024</div>
---
>                 <div class="fs-3 fw-bold">28. septembar 2024</div>
515c513
<                 <div class="fs-xl">Суббота</div>
---
>                 <div class="fs-xl">Subota</div>
517c515
<                 <div class="fs-3 fw-bold">26 Октября 2024</div>
---
>                 <div class="fs-3 fw-bold">26. oktobar 2024</div>
532c530
<                       <!-- <span class="badge bg-info shadow-info fs-sm">В этот раз здесь принимается стекло</span> -->
---
>                       <!-- <span class="badge bg-info shadow-info fs-sm">Samo ovde se prihvata staklo</span> -->
535,536c533,534
<                       <h5>Бар</h5>
<                       <p class="mb-4">У заброшенного бизнес центра за Аромой
---
>                       <h5>Bar</h5>
>                       <p class="mb-4">Napuštena zgrada iza supermarketa Aroma
538,541c536
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5917" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
553,554c548,549
<                       <h5>Сутоморе</h5>
<                       <p>У пекары Mladost
---
>                       <h5>Sutomore</h5>
>                       <p>Kod pekare Mladost
556,559c551
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5921" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
571,572c563,564
<                       <h5>Будва</h5>
<                       <p class="mb-4">На территории школы "Stefan Mitrov Ljubisa"
---
>                       <h5>Budva</h5>
>                       <p class="mb-4">Na terenu škole "Stefan Mitrov Ljubisa"
574,577c566
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5919" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
589,590c578,579
<                       <h5>Котор</h5>
<                       <p class="mb-4">Между парковкой и каналом
---
>                       <h5>Kotor</h5>
>                       <p class="mb-4">U centry između parkinga i kanala
592,595c581
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5929" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
600c586
<                 </div> 
---
>                 </div>
607,608c593,594
<                       <h5>Херцег Нови</h5>
<                       <p class="mb-4">Парковка у ресторана Apetit
---
>                       <h5>Herceg Novi</h5>
>                       <p class="mb-4">Na parkiranju ispred restorana Apetit
610,613c596
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
623c606
<                       <span class="badge bg-success shadow-success fs-sm">Новая локация!</span>
---
>                       <span class="badge bg-success shadow-success fs-sm">Nova lokacija!</span>
626,627c609,610
<                       <h5>Кумбор</h5>
<                       <p class="mb-4">На территории школы "Adriatic Novi"
---
>                       <h5>Kumbor</h5>
>                       <p class="mb-4">Na terenu škole "Adriatic Novi"
629,632c612
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                           Tačka na mapi
644,645c624,625
<                       <h5>Тиват</h5>
<                       <p class="mb-4">Напротив Porto Montenegro, около Komunalno DOO
---
>                       <h5>Tivat</h5>
>                       <p class="mb-4">Ispred Porto Montenegro, pored Komunalno DOO
647,650c627
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5927" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
666,667c643,644
<                       <h5>Бар</h5>
<                       <p class="mb-4">У заброшенного бизнес центра за Аромой
---
>                       <h5>Bar</h5>
>                       <p class="mb-4">Napuštena zgrada iza supermarketa Aroma
669,672c646
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5917" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
684,685c658,659
<                       <h5>Сутоморе</h5>
<                       <p>У пекары Mladost
---
>                       <h5>Sutomore</h5>
>                       <p>Kod pekare Mladost
687,690c661
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5921" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
702,708c673,676
<                       <h5>Будва</h5>
<                       <p class="mb-4">На территории школы "Stefan Mitrov Ljubisa"
<                       <a href="https://goo.gl/maps/zgKWBqrCpkEdasm5" class="btn btn-link px-2">
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5919" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                       <h5>Budva</h5>
>                       <p class="mb-4">Na terenu škole "Stefan Mitrov Ljubisa"
>                       <a href="https://goo.gl/maps/zgKWBqrCpkEdasms5" class="btn btn-link px-2">
>                         Tačka na mapi
720,721c688,689
<                       <h5>Котор</h5>
<                       <p class="mb-4">Между парковкой и каналом
---
>                       <h5>Kotor</h5>
>                       <p class="mb-4">U centry između parkinga i kanala
723,726c691
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5929" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
738,739c703,704
<                       <h5>Херцег Нови</h5>
<                       <p class="mb-4">Парковка у ресторана Apetit
---
>                       <h5>Herceg Novi</h5>
>                       <p class="mb-4">Na parkiranju ispred restorana Apetit
741,744c706
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
754c716
<                       <span class="badge bg-success shadow-success fs-sm">Новая локация!</span>
---
>                       <span class="badge bg-success shadow-success fs-sm">Nova lokacija!</span>
757,758c719,720
<                       <h5>Кумбор</h5>
<                       <p class="mb-4">На территории школы "Adriatic Novi"
---
>                       <h5>Kumbor</h5>
>                       <p class="mb-4">Na terenu škole "Adriatic Novi"
760,763c722
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                           Tačka na mapi
775,776c734,735
<                       <h5>Тиват</h5>
<                       <p class="mb-4">Напротив Porto Montenegro, около Komunalno DOO
---
>                       <h5>Tivat</h5>
>                       <p class="mb-4">Ispred Porto Montenegro, pored Komunalno DOO
778,781c737
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5927" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
799c755
<                 Хотите финансово поучаствовать в акции?
---
>                 Da li želite finansijski da učestvujete u akciji?
804,805c760,761
<             <p class="fs-lg mb-md-5 mb-sm-4 text-center">Вы спросите: "А на что будут потрачены деньги с пожертвований?"<br>
<             Ниже мы подробно расписываем основные категории наших затрат.</p>
---
>             <p class="fs-lg mb-md-5 mb-sm-4 text-center">Vi pitaćete: "A za šta će biti potrošen novac od donacija?"<br>
>             Dole mi detaljno pišemo osnovne kategorije naših troškova.</p>
811c767
<                 <h4 class="h3 pb-1 pb-md-3 pb-lg-4">Благодарим Вас за то, что Вы также неравнодушны к проблеме мусора в Черногории</h4>
---
>                 <h4 class="h3 pb-1 pb-md-3 pb-lg-4">Zahvaljujemo Vam za to što Vi takođe niste ravnodušni prema problemu smeća u Crnoj Gori</h4>
815c771
<                     Покупка пакетов и мешков для приёма вторсырья
---
>                     Kupovina paketa i vreća za prijem reciklaže
819c775
<                     Оплата шофёрам, которые на своих машинах отвозят вторсырьё после акции
---
>                     Uplata šoferima, koji na svojim automobilima odvoze reciklažu posle akcije
823c779
<                     Печать баннеров, плакатов, футболок
---
>                     Štampanje banera, plakata, dresova
827,830c783,787
<                       У нас есть планы на новые проекты по популяризации разделения и переработки мусора:<br>
<                       - Проведение экологических ярмарок<br>
<                       - Проведение детских игр-квестов на местности с уборкой мусора<br>
<                       - Организация в школах лекций по переработке мусора
---
>                       Imamo planove za nove projekte o popularizaciji podele i reciklaže smeća:<br>
>                       - Organizacija eko-taksija, koji bi sakupljao staklo kod stanovnika primorskih regiona<br>
>                       - Organizacija ekoloških sajmova<br>
>                       - Organizacija dečijih igara-potraga na terenu sa čišćenjem smeća<br>
>                       - Organizacija predavanja u školama o reciklaži smeća
841c798
<                 <a href="https://donate.stripe.com/00g0165yO9WR7wk3cc" class="btn btn-lg btn-primary shadow-primary w-100 w-sm-auto">Оставить пожертвование</a>
---
>                 <a href="https://donate.stripe.com/00g0165yO9WR7wk3cc" class="btn btn-lg btn-primary shadow-primary w-100 w-sm-auto">Želim da doniram</a>
848c805
<                   Покупка пакетов и мешков для приёма вторсырья
---
>                   Kupovina paketa i vreća za prijem reciklaže
852c809
<                   Оплата шофёрам, которые на своих машинах отвозят вторсырьё после акции
---
>                   Uplata šoferima, koji na svojim automobilima odvoze reciklažu posle akcije
856c813
<                   Печать баннеров, плакатов, футболок
---
>                   Štampanje banera, plakata, dresova
860,864c817,820
<                   У нас есть планы на новые проекты по популяризации разделения и переработки мусора:<br>
<                   - Организация эко-такси, которое бы собирало стекло у жителей прибрежных районов<br>
<                   - Проведение экологических ярмарок<br>
<                   - Проведение детских игр-квестов на местности с уборкой мусора<br>
<                   - Организация в школах лекций по переработке мусора
---
>                   Imamo planove za nove projekte o popularizaciji podele i reciklaže smeća:<br>
>                   - Organizacija ekoloških sajmova<br>
>                   - Organizacija dečijih igara-potraga na terenu sa čišćenjem smeća<br>
>                   - Organizacija predavanja u školama o reciklaži smeća
884,885c840,841
<           <h3 class="h1 text-center mb-lg-4">Карта с точками приёма вторсырья</h3>
<           <p class="fs-lg text-muted text-center mb-4 mb-lg-5">Кликая по точкам, можно увидеть описание того, что именно принимается в данном месте</p>
---
>           <h3 class="h1 text-center mb-lg-4">Mapa sa tačkama preuzimanja sekundarnih sirovina</h3>
>           <p class="fs-lg text-muted text-center mb-4 mb-lg-5">Klikom na tačke, možete videti šta se tačno prihvata na određenom mestu</p>
890c846

903,906c859,862
<             <h1 class="mb-4">Организаторы</h1>
<             <p class="fs-lg pb-lg-3 mb-4">За успехом такого большого и сложного проекта стоит целая команда движения <strong>"Зелёная Адриатика"</strong>, целью которой является повышение осознанности людей, забота об окружающей среде и популяризация идеи разделения и переработки отходов!</p>
<               <h2 class="h5 mb-4">Отдельное спасибо перерабатывающему кооперативу Reciklažno Dvorište Lovanja</h2>
<             <a href="#" class="btn btn-primary shadow-primary btn-lg">Подробнее об организации</a>
---
>             <h1 class="mb-4">Organizatori</h1>
>             <p class="fs-lg pb-lg-3 mb-4">Iza uspeha tako velikog i složenog projekta stoji ceo tim pokreta <strong>"Zeleni Jadran"</strong>, čiji je cilj da podigne svest ljudi, briga o okruženju i popularizacija ideje razdvajanja i prerađivanja otpada!</p>
>               <h2 class="h5 mb-4">Posebno se zahvaljujemo reciklažom kolektivu Reciklažno Dvorište Lovanja</h2>
>             <a href="#" class="btn btn-primary shadow-primary btn-lg">Detaljnije o organizaciji</a>
909c865
<           <span class="text-light opacity-50">&copy; All rights reserved. Made by </span>
---
>           <span class="text-light opacity-50">&copy; Sva prava rezervisana. Kreirali </span>
