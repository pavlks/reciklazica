---
title: "Reciklažica"
metaDescription: "Reciklažica je akcija sakupljanja sekundarnih sirovina državljana Crne Gore, koja se održava jednom mesečno."
metaKeywords: "prerada, otpad, sekundare sirovine, smeće, akcija, crna gora, bar, sutomore, budva, radanovići, kotor, risan, herceg novi, tivat, podgorica, cetinje, sortiranje, plastika, baterije, aluminijum, papir, karton, gvožđe, kalaj, folija, čepovi"
pageSpinner: "Stranica se učitava..."
firstNavLang: "RU"
secondNavLang: "EN"
lightThemeMode: "Svetao"
darkThemeMode: "Taman"
textH1: "Reciklažica"
textLocations: "Crna Gora,<br>Bar - Sutomore - Budva - Tivat - Kotor - Herceg Novi - Kumbor"
linkTg: "Naš Telegram"
linkFb: "Fejsbuk grupa"
descHeader: "Šta je Reciklažica?"
descText1: "Ovo ste dugo čekali! Prva ekološka akcija u Crnoj Gori - Reciklažica!💚"
descText2: "<em>Svake poslednje subote u mesecu</em> u određenim gradovima Crne Gore, pokret \"Zeleni Jadran\" sakuplja sekundarne sirovine od građana države. "
descText3: "Posle akcije, sekundarne sirovine će se naći na Dvorištu opštine Kotor, gde će biti predate dobavljačima, za dalju predaju prerađivačima."
descText4: "Naša dostignuća"
descText5: "Poslednji put"
descText6: "Ukupno"
descText7: "Za sve vrijeme"
descText8: "gradova učestvuje u akciji, koja se neprestano širi"
descText9: "uspješnih akcija je provedeno"
descText10: "ljudi zainteresovanih za problem. Grupa na Telegramu neprekidno raste"
reHeader: "Šta recikliramo?!"
reText1: "Crna Gora pravi svoje prve korake u sekundarnoj preradi, i trenutno može biti prerađeno i ono što ne bismo hteli da bude."
reText2: "Obratite pažnju, volonteri Reciklažice trenutno primaju <mark>samo 4 tipa sekundarne sirovine:"
rePlastic1: "Plastika"
rePlastic2: "Primaju se sledeće kategorije plastike:"
rePlastic3: "Providne flaše od napitaka (plave, zelene, braon)"
rePlastic4: "Obojene flaše od napitaka (jogurt, kefir)"
rePlastic5: "Pakovanja kućne hemije sa poklopcima (prašak, omekšivač, sredstvo za pranje posuđa, sredstva za čišćenje)"
rePlastic6: "Kese"
rePlastic7: "Čepovi"
rePlastic8: "Kese, kesice sa zatvaračem (ziplock)"
rePlastic9: "Pakovanje mlečnih proizvoda (jogurt, pavlaka, kajmak, sir)"
rePlastic10: "Krupna plastika (stolovi, stolice, kutije)"
reNotPlastic1: "NE PRIHVATAMO:"
reNotPlastic2: "Stiropor"
reNotPlastic3: "Penaste bele kutijice za hranu (sir, šunka)"
reNotPlastic4: "Plastične tube od paste za zube"
reNotPlastic5: "Providna pakovanja za hranu"
reNotPlastic6: "Pakovanje čipsa"
reNotPlastic7: "PVC, cevi za kanalizaciju i sanitarije"
reNotPlastic8: "Najlon (četke za zube, čarape, najlonke)"
reNotPlastic9: "Kese sa naljepnicama"
reNotPlastic10: "PRLJAVO, NEOPRANO"
reMetal1: "Gvožđe, kalaj, aluminijum"
reMetal2: "Prihvatamo sledeće tipove sekundarnih sirovina:"
reMetal3: "Konzerve za hranu od kalaja"
reMetal4: "Aluminijumske konzerve"
reMetal5: "Folija (folija sama po sebi, poklopci od folije/nalepnice od pavlake, jogurta)"
reNotMetal1: "NE PRIHVATAMO:"
reNotMetal2: "Pakovanje od čipsa"
reNotMetal3: "RĐAVO"
reNotMetal4: "PRLJAVO, NEOPRANO"
rePapir1: "Papir, karton"
rePapir2: "Prihvatamo sledeće papirne predmete:"
rePapir3: "Krupan karton (kutije)"
rePapir4: "Kartonska pakovanja (jaja, žitarice, musli, kaše)"
rePapir5: "Papir (novine, knjige, časopisi, sveske)"
reNotPapir1: "NE PRIHVATAMO:"
reNotPapir2: "Termalni papir (računi)"
reNotPapir3: "Tetrapak"
reNotPapir4: "Papir koji sadrži plastiku"
reNotPapir5: "Papir sa selotejpom"
reNotPapir6: "Maramici"
reNotPapir7: "MOKRO, PRLJAVO"
reNotPapir8: "SA MASNIM TRAGOVIMA"

reBattery1: "Baterije"
reBattery2: "Prihvataju se sledeće kategorije:"
reBattery3: "Akumulatori za automobile"
reBattery4: "Alkalne baterije (daljinski upravljači, lampe, AA, AAA)"
reBattery5: "Stare Nikl-kadmijum baterije"
reBattery6: "Stare Nikl-metalohidridne baterije"
reBattery7: "Litijumske baterije (telefoni, kamere, fotoaparati, kompjuteri)"
reBattery8: "Baterijice od srebra i cinka (satovi, ključevi)"
reBattery9: "Elementi od mangana i cinka (velike baterije u baterijskim lampama)"
reNotBattery1: "NE PRIHVATAMO:"
reNotBattery2: "PRLJAVO, NEOPRANO"
reNotBattery3: "RĐAVO"

501c499
<         <div class="row mt-xl-2 mb-xl-3 pb-3 py-md-4 py-lg-5">
---
>         <div class="row pt-1">
503c501
<             <h2 class="h1 text-center text-sm-start pb-2 pb-lg-0 mb-4 mb-lg-5">Расписание</h2>
---
>             <h2 class="h1 text-center text-sm-start pb-2 pb-lg-0 mb-4 mb-lg-5">Raspored</h2>
510c508
<                 <div class="fs-xl">Суббота</div>
---
>                 <div class="fs-xl">Subota</div>
512c510
<                 <div class="fs-3 fw-bold">28 Сентября 2024</div>
---
>                 <div class="fs-3 fw-bold">28. septembar 2024</div>
515c513
<                 <div class="fs-xl">Суббота</div>
---
>                 <div class="fs-xl">Subota</div>
517c515
<                 <div class="fs-3 fw-bold">26 Октября 2024</div>
---
>                 <div class="fs-3 fw-bold">26. oktobar 2024</div>
532c530
<                       <!-- <span class="badge bg-info shadow-info fs-sm">В этот раз здесь принимается стекло</span> -->
---
>                       <!-- <span class="badge bg-info shadow-info fs-sm">Samo ovde se prihvata staklo</span> -->
535,536c533,534
<                       <h5>Бар</h5>
<                       <p class="mb-4">У заброшенного бизнес центра за Аромой
---
>                       <h5>Bar</h5>
>                       <p class="mb-4">Napuštena zgrada iza supermarketa Aroma
538,541c536
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5917" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
553,554c548,549
<                       <h5>Сутоморе</h5>
<                       <p>У пекары Mladost
---
>                       <h5>Sutomore</h5>
>                       <p>Kod pekare Mladost
556,559c551
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5921" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
571,572c563,564
<                       <h5>Будва</h5>
<                       <p class="mb-4">На территории школы "Stefan Mitrov Ljubisa"
---
>                       <h5>Budva</h5>
>                       <p class="mb-4">Na terenu škole "Stefan Mitrov Ljubisa"
574,577c566
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5919" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
589,590c578,579
<                       <h5>Котор</h5>
<                       <p class="mb-4">Между парковкой и каналом
---
>                       <h5>Kotor</h5>
>                       <p class="mb-4">U centry između parkinga i kanala
592,595c581
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5929" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
600c586
<                 </div> 
---
>                 </div>
607,608c593,594
<                       <h5>Херцег Нови</h5>
<                       <p class="mb-4">Парковка у ресторана Apetit
---
>                       <h5>Herceg Novi</h5>
>                       <p class="mb-4">Na parkiranju ispred restorana Apetit
610,613c596
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
623c606
<                       <span class="badge bg-success shadow-success fs-sm">Новая локация!</span>
---
>                       <span class="badge bg-success shadow-success fs-sm">Nova lokacija!</span>
626,627c609,610
<                       <h5>Кумбор</h5>
<                       <p class="mb-4">На территории школы "Adriatic Novi"
---
>                       <h5>Kumbor</h5>
>                       <p class="mb-4">Na terenu škole "Adriatic Novi"
629,632c612
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                           Tačka na mapi
644,645c624,625
<                       <h5>Тиват</h5>
<                       <p class="mb-4">Напротив Porto Montenegro, около Komunalno DOO
---
>                       <h5>Tivat</h5>
>                       <p class="mb-4">Ispred Porto Montenegro, pored Komunalno DOO
647,650c627
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5927" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
666,667c643,644
<                       <h5>Бар</h5>
<                       <p class="mb-4">У заброшенного бизнес центра за Аромой
---
>                       <h5>Bar</h5>
>                       <p class="mb-4">Napuštena zgrada iza supermarketa Aroma
669,672c646
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5917" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
684,685c658,659
<                       <h5>Сутоморе</h5>
<                       <p>У пекары Mladost
---
>                       <h5>Sutomore</h5>
>                       <p>Kod pekare Mladost
687,690c661
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5921" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
702,708c673,676
<                       <h5>Будва</h5>
<                       <p class="mb-4">На территории школы "Stefan Mitrov Ljubisa"
<                       <a href="https://goo.gl/maps/zgKWBqrCpkEdasm5" class="btn btn-link px-2">
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5919" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                       <h5>Budva</h5>
>                       <p class="mb-4">Na terenu škole "Stefan Mitrov Ljubisa"
>                       <a href="https://goo.gl/maps/zgKWBqrCpkEdasms5" class="btn btn-link px-2">
>                         Tačka na mapi
720,721c688,689
<                       <h5>Котор</h5>
<                       <p class="mb-4">Между парковкой и каналом
---
>                       <h5>Kotor</h5>
>                       <p class="mb-4">U centry između parkinga i kanala
723,726c691
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5929" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
738,739c703,704
<                       <h5>Херцег Нови</h5>
<                       <p class="mb-4">Парковка у ресторана Apetit
---
>                       <h5>Herceg Novi</h5>
>                       <p class="mb-4">Na parkiranju ispred restorana Apetit
741,744c706
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
754c716
<                       <span class="badge bg-success shadow-success fs-sm">Новая локация!</span>
---
>                       <span class="badge bg-success shadow-success fs-sm">Nova lokacija!</span>
757,758c719,720
<                       <h5>Кумбор</h5>
<                       <p class="mb-4">На территории школы "Adriatic Novi"
---
>                       <h5>Kumbor</h5>
>                       <p class="mb-4">Na terenu škole "Adriatic Novi"
760,763c722
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5925" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                           Tačka na mapi
775,776c734,735
<                       <h5>Тиват</h5>
<                       <p class="mb-4">Напротив Porto Montenegro, около Komunalno DOO
---
>                       <h5>Tivat</h5>
>                       <p class="mb-4">Ispred Porto Montenegro, pored Komunalno DOO
778,781c737
<                         Точка на карте
<                       <i class="bx bx-right-arrow-alt fs-xl ms-2"></i>
<                       </a><a href="https://t.me/ecomontenegro/5927" class="btn btn-link text-info px-2">
<                           Задать вопрос
---
>                         Tačka na mapi
799c755
<                 Хотите финансово поучаствовать в акции?
---
>                 Da li želite finansijski da učestvujete u akciji?
804,805c760,761
<             <p class="fs-lg mb-md-5 mb-sm-4 text-center">Вы спросите: "А на что будут потрачены деньги с пожертвований?"<br>
<             Ниже мы подробно расписываем основные категории наших затрат.</p>
---
>             <p class="fs-lg mb-md-5 mb-sm-4 text-center">Vi pitaćete: "A za šta će biti potrošen novac od donacija?"<br>
>             Dole mi detaljno pišemo osnovne kategorije naših troškova.</p>
811c767
<                 <h4 class="h3 pb-1 pb-md-3 pb-lg-4">Благодарим Вас за то, что Вы также неравнодушны к проблеме мусора в Черногории</h4>
---
>                 <h4 class="h3 pb-1 pb-md-3 pb-lg-4">Zahvaljujemo Vam za to što Vi takođe niste ravnodušni prema problemu smeća u Crnoj Gori</h4>
815c771
<                     Покупка пакетов и мешков для приёма вторсырья
---
>                     Kupovina paketa i vreća za prijem reciklaže
819c775
<                     Оплата шофёрам, которые на своих машинах отвозят вторсырьё после акции
---
>                     Uplata šoferima, koji na svojim automobilima odvoze reciklažu posle akcije
823c779
<                     Печать баннеров, плакатов, футболок
---
>                     Štampanje banera, plakata, dresova
827,830c783,787
<                       У нас есть планы на новые проекты по популяризации разделения и переработки мусора:<br>
<                       - Проведение экологических ярмарок<br>
<                       - Проведение детских игр-квестов на местности с уборкой мусора<br>
<                       - Организация в школах лекций по переработке мусора
---
>                       Imamo planove za nove projekte o popularizaciji podele i reciklaže smeća:<br>
>                       - Organizacija eko-taksija, koji bi sakupljao staklo kod stanovnika primorskih regiona<br>
>                       - Organizacija ekoloških sajmova<br>
>                       - Organizacija dečijih igara-potraga na terenu sa čišćenjem smeća<br>
>                       - Organizacija predavanja u školama o reciklaži smeća
841c798
<                 <a href="https://donate.stripe.com/00g0165yO9WR7wk3cc" class="btn btn-lg btn-primary shadow-primary w-100 w-sm-auto">Оставить пожертвование</a>
---
>                 <a href="https://donate.stripe.com/00g0165yO9WR7wk3cc" class="btn btn-lg btn-primary shadow-primary w-100 w-sm-auto">Želim da doniram</a>
848c805
<                   Покупка пакетов и мешков для приёма вторсырья
---
>                   Kupovina paketa i vreća za prijem reciklaže
852c809
<                   Оплата шофёрам, которые на своих машинах отвозят вторсырьё после акции
---
>                   Uplata šoferima, koji na svojim automobilima odvoze reciklažu posle akcije
856c813
<                   Печать баннеров, плакатов, футболок
---
>                   Štampanje banera, plakata, dresova
860,864c817,820
<                   У нас есть планы на новые проекты по популяризации разделения и переработки мусора:<br>
<                   - Организация эко-такси, которое бы собирало стекло у жителей прибрежных районов<br>
<                   - Проведение экологических ярмарок<br>
<                   - Проведение детских игр-квестов на местности с уборкой мусора<br>
<                   - Организация в школах лекций по переработке мусора
---
>                   Imamo planove za nove projekte o popularizaciji podele i reciklaže smeća:<br>
>                   - Organizacija ekoloških sajmova<br>
>                   - Organizacija dečijih igara-potraga na terenu sa čišćenjem smeća<br>
>                   - Organizacija predavanja u školama o reciklaži smeća
884,885c840,841
<           <h3 class="h1 text-center mb-lg-4">Карта с точками приёма вторсырья</h3>
<           <p class="fs-lg text-muted text-center mb-4 mb-lg-5">Кликая по точкам, можно увидеть описание того, что именно принимается в данном месте</p>
---
>           <h3 class="h1 text-center mb-lg-4">Mapa sa tačkama preuzimanja sekundarnih sirovina</h3>
>           <p class="fs-lg text-muted text-center mb-4 mb-lg-5">Klikom na tačke, možete videti šta se tačno prihvata na određenom mestu</p>
890c846
903,906c859,862
<             <h1 class="mb-4">Организаторы</h1>
<             <p class="fs-lg pb-lg-3 mb-4">За успехом такого большого и сложного проекта стоит целая команда движения <strong>"Зелёная Адриатика"</strong>, целью которой является повышение осознанности людей, забота об окружающей среде и популяризация идеи разделения и переработки отходов!</p>
<               <h2 class="h5 mb-4">Отдельное спасибо перерабатывающему кооперативу Reciklažno Dvorište Lovanja</h2>
<             <a href="#" class="btn btn-primary shadow-primary btn-lg">Подробнее об организации</a>
---
>             <h1 class="mb-4">Organizatori</h1>
>             <p class="fs-lg pb-lg-3 mb-4">Iza uspeha tako velikog i složenog projekta stoji ceo tim pokreta <strong>"Zeleni Jadran"</strong>, čiji je cilj da podigne svest ljudi, briga o okruženju i popularizacija ideje razdvajanja i prerađivanja otpada!</p>
>               <h2 class="h5 mb-4">Posebno se zahvaljujemo reciklažom kolektivu Reciklažno Dvorište Lovanja</h2>
>             <a href="#" class="btn btn-primary shadow-primary btn-lg">Detaljnije o organizaciji</a>
909c865
941c897
<           <span class="text-light opacity-50">&copy; All rights reserved. Made by </span>
---
>           <span class="text-light opacity-50">&copy; Sva prava rezervisana. Kreirali </span>
